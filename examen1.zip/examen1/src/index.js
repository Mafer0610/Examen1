const express = require('express');
const path = require('path');
const allRouter = require('./router/apiRouter');

const app = express();
const port = 3000;

app.use(allRouter);

app.listen(port, () => {
    console.log(`Servidor escuchando en el puerto ${port}`);
});