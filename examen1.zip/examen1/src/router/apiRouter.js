const express = require('express');
const { getApiServicios } = require('../controller/apiController');

const router = express.Router();

router.get('/api/servicio', getApiServicios);

module.exports = router;